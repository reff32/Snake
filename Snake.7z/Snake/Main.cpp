#include"Snake.h"
#include<iostream>
using namespace std;

int main()
{
	RenderWindow game_mode(sf::VideoMode(640, 480), "Snake");
    Snake_head head("master.png");
    head.set_position(200, 200);
    //cout << master.get_snake_x();
    Snake_body b1("slave.png",1);
   // slave.set_position(100, 100);
    //cout<<master.get_snake_x()-master.size()<<endl;
    b1.set_master(head);
    Snake_body b2("slave.png", 2);
    //b2.set_position(100, 100);
    b2.set_master(b2);
   //cout << slave.size();
    

    while (game_mode.isOpen())
    {
        Event event;
        while (game_mode.pollEvent(event))
        {
            if (event.type == Event::Closed)
                game_mode.close();
        }
        game_mode.clear();
        game_mode.draw(head.set_sprite());
        game_mode.draw(b1.set_sprite());
        game_mode.draw(b2.set_sprite());
        game_mode.display();
    }
	return 0;
}