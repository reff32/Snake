#include "Snake.h"
#include "Snake.h"

//base methods
Snake_base::Snake_base(String filename)
{
	snake_filename = filename;
	snake_img.loadFromFile("images/" + snake_filename);
	snake_img.createMaskFromColor(Color(255, 255, 255));
	snake_tex.loadFromImage(snake_img);
	snake_spr.setTexture(snake_tex);
	snake_size=snake_tex.getSize();
	snake_x = 0;
	snake_y = 0;
	
}

Sprite& Snake_base::set_sprite()
{
	return snake_spr;
}

float Snake_base::get_snake_x() const
{
	return snake_x;
}

float Snake_base::get_snake_y() const
{
	return snake_y;
}

void Snake_base::set_position(float x,float y)
{
	snake_x = x;
	snake_y = y;
	snake_spr.setPosition(snake_x,snake_y);
}

unsigned int Snake_base::size_x()
{
	return snake_size.x;
}


////////////////////////////////////////////////////////////////
//body methods
Snake_body::Snake_body(String filename=" ", int num=1):Snake_base(filename)
{
	slave_num = num;	
}

void Snake_body::set_master(Snake_head& sh)
{
	snake_x = sh.get_snake_x() - size_x();
	snake_y = sh.get_snake_y();
	set_position(snake_x, snake_y);
}

void Snake_body::set_master(Snake_body& sb)
{
	snake_x = /*sb.get_snake_x()*/100 - size_x();
	snake_y = sb.get_snake_y();
	set_position(snake_x, snake_y);
}

