#pragma once
#include<SFML/Graphics.hpp>
using namespace sf;



class Snake_base//abstract base class
{
private:
	String snake_filename;
	Image snake_img;
	Texture snake_tex;
	Sprite snake_spr;
	float snake_dx;
	float snake_dy;
	float snake_speed;
	Vector2u snake_size;
	float snake_x;
	float snake_y;
	

public:
	Snake_base(String filename=" ");
	virtual ~Snake_base(){}
	virtual Sprite& set_sprite();
	virtual float get_snake_x() const;
	virtual float get_snake_y() const;
	virtual void set_position(float x,float y);
	virtual unsigned int size_x();
	

	


};

/////////////////////////////////////////////////
class Snake_head :public Snake_base
{
private:
	String snake_filename;
	Image snake_img;
	Texture snake_tex;
	Sprite snake_spr;
	float snake_dx;
	float snake_dy;
	float snake_speed;
	Vector2u snake_size;
	float snake_x;
	float snake_y;
	unsigned int snake_width;
	unsigned int snake_height;
	
public:
	Snake_head(String filename = " ") : Snake_base(filename) {}
	

};


////////////////////////////////////////////////////////
class Snake_body :public Snake_base
{
private:
	Image snake_img;
	Texture snake_tex;
	Sprite snake_spr;
	String snake_file;
	float snake_dx;
	float snake_dy;
	float snake_speed;
	Vector2u snake_size;
	float snake_x;
	float snake_y;
	unsigned int snake_width;
	unsigned int snake_height;
	int snake_type;
	int slave_num;
public:
	Snake_body(String filename, int num);
	void set_master(Snake_head& sh);
	void set_master(Snake_body& sb);


};
